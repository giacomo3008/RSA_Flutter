# Esito della verifica del RASD

Il RASD descrive correttamente il nucleo evento → notifica → diario → consegna, ma il testo fornito non copriva in modo sufficiente il frontend attuale. La revisione mantiene i requisiti del sistema definitivo e segnala dove il codice implementa solo un comportamento locale.

## Cosa è stato corretto o aggiunto

1. **Sette ruoli**, non soltanto infermiere, tecnico e medico: aggiunti operatore assistenziale, coordinatore, direzione e amministratore, con assegnazioni per reparto e distinzione tra capacità cliniche e amministrative.
2. **Flutter/Dart selezionato**: React resta un riferimento visivo, non la tecnologia del frontend corrente. Il testo sul vecchio prototipo Telegram non è più attribuito al Flutter attuale.
3. **Login e logout**, nessuna registrazione pubblica, utenti creati manualmente nel database. L'ingresso attuale senza credenziali in Emily non soddisfa il requisito futuro di autenticazione SSO/MFA.
4. **Conversazioni**: perimetro di gruppo/evento, chat dirette e assistente privato; chat evento nell'elenco solo dopo apertura personale; pulsante per la nuova conversazione; conversione di un messaggio in report dopo revisione esplicita.
5. **Inbox**: My items significa ricevuti/presi in carico, non creati da me. Ward riguarda le notifiche visibili del reparto attivo. Il diario comprende anche Low e Closed e ha una funzione diversa.
6. **Correzioni dei report**: note attribuite aggiunte all'originale, senza sostituzione dei campi strutturati. Lo storico del report non è il registro completo delle letture.
7. **Consegne**: contenuto e fonti congelati alla firma, attività all'interno della bozza, nuove versioni dopo amendment, visualizzazione storica in sola lettura e ricevute associate alla versione esatta.
8. **Contributi dopo la firma**: rimangono aggiornamenti separati in attesa; il coordinatore li include in una nuova bozza da approvare. Questa è una policy derivata dall'implementazione, da validare con il reparto.
9. **Document review**: era già prevista da R26–R28. Separati OCR, trascrizione manuale, conferma del testo e validazione clinica. Non è dichiarato un OCR reale su nuove immagini.
10. **Nuovi requisiti R42–R59 e casi d'uso UC15–UC18**, con basi, esempi di accettazione e tracciabilità. Definiti i punti aperti O1–O12, richiamati ma assenti nel testo originale.
11. **Correzioni LaTeX**: aggiunto l'argomento Basis mancante in R1–R16, completati IF-04 e G7, corretti riferimenti e refusi; autori e originale preservati.

## Differenze che restano esplicite

- Il requisito R11 prevede residenti assegnati all'operatore nel turno; il codice filtra oggi i residenti per reparto.
- AI, OCR e speech-to-text esterni, push reali, SSO/MFA, API protette, archivio cifrato, conservazione/audit separati e connettori non sono integrati.
- Il pannello Sources and activity mostra il tempo di creazione della notifica accanto al livello di escalation, non il tempo effettivo del passaggio di livello. Inoltre è limitato alle notifiche visibili all'utente: un elenco vuoto a un non destinatario non prova l'assenza di destinatari.
- Le identità storiche mantengono un riferimento stabile e un fallback sicuro all'ID; non tutti i record conservano nome e ruolo immutabili al momento dell'azione.
- I conteggi di Management non includono tempi di risposta misurati. Il filtro data riguarda gli eventi, mentre Staff on duty now è attuale; High priority comprende anche eventi chiusi.
- Turnistica completa, presenze indipendenti per reparto, responsabilità/delega, soglie, validazione obbligatoria e politica di nuove conferme richiedono integrazione o approvazione.

Il capitolo di consistenza nel RASD contiene la matrice dettagliata di R1–R59 e il registro delle decisioni aperte. La guida italiana separata raccoglie le spiegazioni operative richieste nella conversazione, con immagini reali e ingrandimenti.
