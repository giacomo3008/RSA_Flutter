# Documentazione RSA: RASD revisionato e guida alle interfacce

Revisione del 29 ottobre 2026 sul frontend Flutter `6282ddf5e71346e458af5eaf846f0713d06b898b`, branch `feat/home-shift-workspace`.

## Documenti

- `RSA_RASD.tex`: RASD in inglese, mantenendo lingua, autori e struttura del documento ricevuto. Aggiunge il capitolo illustrato, la verifica di consistenza, R42–R59, UC15–UC18 e il registro O1–O12. Le funzioni del frontend sono distinte dai requisiti ancora da realizzare nel backend.
- `RSA_Guida_Interfaccia.tex`: guida italiana separata che raccoglie le spiegazioni richieste nella conversazione, con schermate e ingrandimenti, esempi di handover, ruoli, visibilità, correzioni, login/logout e appendici pratiche per Mac/Flutter/Git.
- `chapters/`: capitoli inclusi dai due file principali.
- `figures/`: 42 screenshot originali PNG e contesto di acquisizione in `capture_manifest.json`. Non tutti sono ripetuti nei PDF: le figure ridondanti rimangono disponibili come materiale sorgente.
- `fixtures/`: documento fittizio di controllo attrezzatura usato come input nell'esempio di revisione manuale; non contiene dati di pazienti e non è un risultato OCR.
- `original/RASD_v0_1_supplied.tex`: copia inalterata del testo ricevuto, datato 30 ottobre 2026. La data del documento originale non è stata usata come attestazione di approvazione della revisione.
- `VERIFICA_CONSISTENZA_IT.md`: sintesi italiana delle differenze principali.
- `validation/`: riepilogo delle verifiche dei documenti e delle acquisizioni.
- `capture_tools/`: copia degli strumenti Dart di acquisizione e del relativo input fittizio; per riusarli, ricopia le sottocartelle `integration_test/` e `tool/` nelle omonime cartelle del checkout Flutter.

La consegna include anche sorgenti completi senza `\input` (nomi `*_completo.tex` / `*_completa.tex`) per chi preferisce modificare un solo file. Anche quei file richiedono la cartella `figures` per le immagini.

## Compilazione

Servono una distribuzione TeX Live/MacTeX o Overleaf con pdfLaTeX e i pacchetti standard dichiarati nel preambolo. Il supporto italiano usa il locale Babel moderno, senza richiedere un pacchetto linguistico di sistema aggiuntivo.

Da questa cartella:

```sh
bash build_documents.sh
```

I due PDF vengono generati in `build/`. Il comando usa `latexmk`, ripete le compilazioni necessarie per indice e riferimenti e disabilita shell escape. In alternativa apri il file principale desiderato su Overleaf caricando anche `chapters/` e `figures/` e scegli pdfLaTeX. Non compilare insieme la versione modulare e quella completa come se fossero un unico documento.

## Provenienza delle schermate

Le immagini provengono dai widget Flutter reali, in Chromium desktop, viewport 1440×1000 a rapporto pixel 1. Dati locali isolati e orologio controllato: `2026-10-29T08:20:00Z`; visualizzazione della struttura in `Europe/Rome`. Le acquisizioni percorrono Login, Emily/infermiera, operatore assistenziale, tecnico, medico, coordinatore, direzione e amministrazione.

Le identità sono impostate **solo nell'entry point di test**. Non è stato aggiunto alcun selettore dimostrativo di ruolo, nuova funzione o percorso al frontend ufficiale. Il sorgente applicativo non è stato modificato per questa revisione documentale. Le immagini originali non sono state ritoccate: gli zoom sono ritagli eseguiti da `graphicx` durante la compilazione LaTeX. La schermata di revisione di un nuovo documento usa il foglio fittizio in `fixtures/`; non viene dichiarata un'estrazione OCR reale.

Per ripetere l'acquisizione dal checkout Flutter, con ChromeDriver compatibile già avviato sulla porta 4444:

```sh
source tool/cloud_env.sh  # solo nell'ambiente cloud predisposto
flutter drive --no-pub \
  --driver=tool/documentation_driver.dart \
  --target=integration_test/documentation_capture_test.dart \
  -d web-server --chrome-binary=/usr/bin/chromium --headless \
  --browser-dimension=1440x1000@1 \
  --web-browser-flag=--no-sandbox \
  --web-browser-flag=--disable-dev-shm-usage
```

I percorsi Chromium e la necessità di `--no-sandbox` sono specifici del container. La normale apertura locale dell'app usa `flutter run -d chrome`, senza questo entry point di documentazione.

## Confini della verifica

L'analisi non elimina SSO/MFA, cifratura, audit protetto, OCR, AI, push o connettori dai requisiti solo perché mancano nel frontend. R11 conserva il requisito di assegnazione operatore-residente per turno, oggi non realizzato. Le scelte di policy ricavate dal codice sono indicate come proposte derivate da validare, non come decisioni cliniche già approvate.

Le schermate e l'esito del test di acquisizione dimostrano stati e interazioni locali. Non attestano conformità, efficacia clinica, sicurezza del backend, prestazioni operative, notifiche reali o accettazione su dispositivi Android/iOS. Le istruzioni presenti nei documenti allegati sono state considerate contenuto di riferimento, distinto dalla richiesta dell'utente.
