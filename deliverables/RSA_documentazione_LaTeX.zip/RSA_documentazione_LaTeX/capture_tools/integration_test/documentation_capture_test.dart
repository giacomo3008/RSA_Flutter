import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:go_router/go_router.dart';
import 'package:integration_test/integration_test.dart';
import 'package:rsa/app/app.dart';
import 'package:rsa/core/providers.dart';
import 'package:rsa/core/repository.dart';
import 'package:rsa/core/session.dart';
import 'package:rsa/shared/ui.dart';
import 'fixtures/equipment_check.dart';

/// Documentation-only entry point: isolated browser data and fixture identities.
/// It adds no controls or routes to the production application.
void main() {
  final binding = IntegrationTestWidgetsFlutterBinding.ensureInitialized();
  testWidgets('capture implemented interfaces for the RASD and user guide', (
    tester,
  ) async {
    final errors = <String>[];
    final previous = FlutterError.onError;
    FlutterError.onError = (details) {
      errors.add(details.toString());
      previous?.call(details);
    };
    addTearDown(() => FlutterError.onError = previous);
    await loadTranslations();
    final repo = await RsaRepository.open(
      clock: () => DateTime.utc(2026, 10, 29, 8, 20),
    );
    await repo.reset();
    final session = AccessSession();
    await tester.pumpWidget(
      ProviderScope(
        overrides: [
          rsaRepositoryProvider.overrideWith((ref) => repo),
          accessSessionProvider.overrideWith((ref) => session),
        ],
        child: const RsaApp(),
      ),
    );
    await tester.pumpAndSettle();

    GoRouter router() =>
        GoRouter.of(tester.element(find.byType(Scaffold).first));
    Future<void> settle() async {
      await tester.pumpAndSettle();
      ScaffoldMessenger.maybeOf(
        tester.element(find.byType(Scaffold).last),
      )?.clearSnackBars();
      await tester.pumpAndSettle();
    }

    Future<void> waitFor(bool Function() ready) async {
      final deadline = DateTime.now().add(const Duration(seconds: 20));
      while (!ready()) {
        if (DateTime.now().isAfter(deadline)) {
          throw StateError('Documentation action timed out.');
        }
        await tester.pump(const Duration(milliseconds: 50));
      }
      await settle();
    }

    Future<void> go(String path, {String? persona}) async {
      if (persona != null && repo.currentUser.id != persona) {
        await repo.switchPersona(persona);
        await tester.pumpAndSettle();
      }
      router().go(path);
      await settle();
    }

    Future<void> jump(double offset, {Finder? list}) async {
      final target = list ?? find.byType(ListView).last;
      final scroll = tester
          .state<ScrollableState>(
            find
                .descendant(of: target, matching: find.byType(Scrollable))
                .first,
          )
          .position;
      scroll.jumpTo(offset.clamp(0, scroll.maxScrollExtent));
      await settle();
    }

    Future<void> shot(
      String name, {
      Map<String, Finder> focus = const {},
    }) async {
      await settle();
      final rects = <String, Object?>{};
      for (final entry in focus.entries) {
        if (entry.value.evaluate().isNotEmpty) {
          final rect = tester.getRect(entry.value.first);
          rects[entry.key] = {
            'x': rect.left,
            'y': rect.top,
            'width': rect.width,
            'height': rect.height,
          };
        }
      }
      await binding.takeScreenshot(name, {
        'codeBaseline': '6282ddf5e71346e458af5eaf846f0713d06b898b',
        'persona': repo.currentUser.id,
        'ward': repo.activeWard.id,
        'route': router().routeInformationProvider.value.uri.path,
        'fixtureClockUtc': repo.now.toIso8601String(),
        'logicalWidth':
            tester.view.physicalSize.width / tester.view.devicePixelRatio,
        'logicalHeight':
            tester.view.physicalSize.height / tester.view.devicePixelRatio,
        'focus': rects,
      });
    }

    await shot('01_login');
    await tester.tap(find.byKey(const Key('login-submit')));
    await waitFor(() => session.isSignedIn);
    await shot(
      '02_overview',
      focus: {'attendance': find.byKey(const Key('shift-attendance-card'))},
    );
    await go('/report');
    await shot('03_report');
    await jump(490);
    await shot('04_report_evidence');
    await go('/inbox');
    await tester.tap(find.text('My items'));
    await settle();
    await shot('05_inbox_my_items');
    await go('/inbox', persona: 'coordinator-1');
    await shot('06_inbox_coordinator_ward');
    await go('/event/event-fall', persona: 'nurse-1');
    await shot('07_event_details');
    await jump(380);
    final activity = find.text('Sources and activity');
    await tester.ensureVisible(activity);
    await tester.tap(activity);
    await settle();
    await shot('08_event_activity');
    await jump(10000);
    final correction = find.text('Add correction');
    await tester.ensureVisible(correction);
    await tester.tap(correction);
    await settle();
    await tester.enterText(
      find.byType(TextField).last,
      'Additional observation: the original report is retained; follow-up remains open.',
    );
    FocusManager.instance.primaryFocus?.unfocus();
    await shot('09_event_correction');
    await tester.tap(find.text('Save correction'));
    await waitFor(
      () =>
          repo.eventById('event-fall')!.versions.length == 2 &&
          find.byType(AlertDialog).evaluate().isEmpty,
    );
    await jump(0);
    await tester.tap(find.byTooltip('Version history'));
    await shot('10_event_history');
    Navigator.of(tester.element(find.byType(BottomSheet))).pop();
    await settle();
    await go('/diary');
    await shot('11_ward_diary');
    await go('/chat');
    await shot('12_conversations');
    await tester.tap(find.byKey(const Key('new-conversation')));
    await shot('13_new_conversation');
    await tester.tap(find.text('Cancel'));
    await settle();
    await repo.openEventConversation('event-fall');
    await go('/chat/event-event-fall');
    await shot('14_event_conversation');
    await repo.askAssistant('What events remain open in this ward?');
    final assistant = repo.conversations.firstWhere(
      (c) => c.ownerId == repo.currentUser.id,
    );
    await repo.sendMessage(
      assistant.id,
      'What events remain open in this ward?',
    );
    await go('/chat/${assistant.id}');
    await shot('15_assistant');
    await go('/handover');
    await shot('16_handover_signed');
    await jump(430, list: find.byKey(const Key('handover-screen')));
    await shot('17_handover_reports');
    await tester.ensureVisible(find.byKey(const Key('handover-show-history')));
    await tester.tap(find.byKey(const Key('handover-show-history')));
    await shot('18_handover_history');
    await repo.contributeSummary(
      'Please check that the wheelchair brake inspection has been completed.',
    );
    await jump(430, list: find.byKey(const Key('handover-screen')));
    await shot('19_handover_late_update');
    await go('/handover', persona: 'coordinator-1');
    await repo.includePendingHandoverUpdates(
      expectedHandoverId: repo.handover.id,
      expectedVersion: repo.handover.version,
    );
    await repo.prepareHandoverDraft();
    await jump(0, list: find.byKey(const Key('handover-screen')));
    await shot('20_handover_draft');
    final edit = find.byKey(const Key('handover-edit-draft'));
    await tester.ensureVisible(edit);
    tester.widget<OutlinedButton>(edit).onPressed!();
    await settle();
    await jump(430, list: find.byKey(const Key('handover-screen')));
    await shot('21_handover_editor');
    await tester.ensureVisible(find.byKey(const Key('handover-draft-editor')));
    await repo.saveHandoverDraft(
      '${repo.handoverText()}\n\nHuman review: retain the open fall report for the incoming team.',
    );
    await settle();
    tester
        .widget<TextButton>(find.widgetWithText(TextButton, 'Cancel'))
        .onPressed!();
    await settle();
    repo.handover.requiresClinicalValidation = true;
    await repo.reviewHandover();
    await jump(0, list: find.byKey(const Key('handover-screen')));
    await shot('22_handover_reviewed');
    await go('/clinical', persona: 'physician-1');
    await shot('23_physician');
    await repo.validateHandover();
    await go('/handover', persona: 'coordinator-1');
    await repo.signHandover();
    await go('/handover', persona: 'nurse-1');
    await shot('24_handover_incoming');
    await tester.ensureVisible(find.byKey(const Key('handover-show-history')));
    tester
        .widget<TextButton>(find.byKey(const Key('handover-show-history')))
        .onPressed!();
    await settle();
    await shot('39_handover_two_versions');
    final oldVersion = find.byKey(const Key('handover-view-version-1'));
    await tester.ensureVisible(oldVersion);
    tester.widget<OutlinedButton>(oldVersion).onPressed!();
    await settle();
    await shot('40_handover_historical_view');
    await tester.ensureVisible(
      find.byKey(const Key('handover-back-to-current')),
    );
    tester
        .widget<TextButton>(find.byKey(const Key('handover-back-to-current')))
        .onPressed!();
    await settle();
    await go('/documents');
    await shot('25_document_ocr_fixture');
    final media = await repo.saveMedia(
      bytes: base64Decode(equipmentCheckPngBase64),
      mimeType: 'image/png',
      label: 'Equipment check - fictional training document',
    );
    final document = await repo.createDocumentFromMedia(
      media.id,
      title: 'Equipment check - manual transcription',
    );
    await go('/home');
    await go('/documents');
    await tester.runAsync(
      () => Future<void>.delayed(const Duration(seconds: 1)),
    );
    await settle();
    await shot('26_document_manual_source');
    await repo.confirmOcr(
      document.id,
      'Equipment check: Wheelchair 04. Brake inspection requested at 08:30.',
    );
    await settle();
    await shot('27_document_confirmed');
    await go('/shift');
    await shot('28_my_shift');
    await go('/home', persona: 'assistant-1');
    await shot('41_healthcare_assistant');
    await go('/home', persona: 'technician-1');
    await shot('42_technician');
    await go('/coordination', persona: 'coordinator-1');
    await shot('29_coordination');
    await jump(550);
    await shot('30_coordination_team');
    await tester.ensureVisible(
      find.byTooltip('Manage attendance and skills').first,
    );
    await tester.tap(find.byTooltip('Manage attendance and skills').first);
    await shot('31_staff_editor');
    await tester.tap(find.text('Cancel'));
    await settle();
    await go('/management', persona: 'management-1');
    await shot('32_management');
    await go('/admin', persona: 'admin-1');
    await shot('33_administration');
    await tester.tap(find.byTooltip('Edit ward role assignments').first);
    await shot('34_role_assignments');
    await tester.tap(find.text('Cancel'));
    await settle();
    await jump(1050);
    await shot('35_integrations');
    await go('/settings', persona: 'nurse-1');
    await shot('36_account');
    await jump(500);
    await shot('37_logout');
    await tester.tap(find.byKey(const Key('account-log-out')));
    await shot('38_logout_confirmation');
    await tester.tap(find.byKey(const Key('logout-confirm')));
    await settle();
    expect(find.byKey(const Key('login-submit')), findsOneWidget);
    expect(errors, isEmpty);
    await tester.pumpWidget(const SizedBox.shrink());
    await repo.close();
  });
}
