import 'dart:convert';
import 'dart:io';
import 'package:integration_test/integration_test_driver_extended.dart';

Future<void> main() async {
  final output = Directory('docs/rasd_review/figures')
    ..createSync(recursive: true);
  final manifest = <String, Object?>{};
  await integrationDriver(
    writeResponseOnFailure: true,
    onScreenshot: (name, bytes, [args]) async {
      await File('${output.path}/$name.png').writeAsBytes(bytes);
      manifest[name] = args;
      await File(
        '${output.path}/capture_manifest.json',
      ).writeAsString(const JsonEncoder.withIndent('  ').convert(manifest));
      return true;
    },
  );
}
