#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
mkdir -p build
for source_document in RSA_RASD.tex RSA_Guida_Interfaccia.tex; do
  latexmk -pdf -interaction=nonstopmode -halt-on-error \
    -pdflatex='pdflatex -no-shell-escape %O %S' \
    -outdir=build "$source_document"
done
