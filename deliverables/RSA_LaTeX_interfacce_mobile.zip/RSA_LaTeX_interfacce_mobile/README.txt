RASD con il solo capitolo delle interfacce aggiunto.

Compila main.tex con pdfLaTeX (due passaggi per aggiornare l'indice).
Su Overleaf carica tutti i file e la cartella screens; scegli main.tex come documento principale.

RASD.tex è identico, byte per byte, al testo allegato: nessun contenuto è stato modificato.
main.tex include il documento e aggiunge soltanto interfacce.tex alla fine.
Contiene anche un adattamento tecnico alla macro req, perché R14-R16 nel file allegato hanno tre argomenti anziché quattro: evita l'errore di compilazione senza cambiare il file originale o aggiungere testo ai requisiti.

Il nuovo capitolo è di 9 pagine, con 18 schermate del layout telefono, due per pagina.
Anteprima_interfacce.pdf permette di consultare subito il solo capitolo aggiunto.
